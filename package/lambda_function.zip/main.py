import json
import os
import boto3
import uuid
import datetime
from botocore.exceptions import BotoCoreError, ClientError
import logging
import jwt
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from utils import decode_id_token, extract_user_details, create_response, generate_title

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize AWS resources
dynamodb = boto3.resource("dynamodb", region="ap-southeast-1")
table = dynamodb.Table(os.environ.get('TABLE_NAME', 'chat-db'))

# Bedrock Agent Configuration
AGENT_ID = os.getenv('AGENT_ID', "")
AGENT_ALIAS_ID = os.getenv('AGENT_ALIAS_ID', "")


# Pydantic Models
class ChatRole(str, Enum):
    """Enumerates the possible roles in a conversation."""
    user = "user"
    assistant = "assistant"
    system = "system"


class TextContent(BaseModel):
    """Represents the text content of a message."""
    text: str = Field(default=None, examples=["Hello!"])


# Pydantic model for a message in the chat
class Message(BaseModel):
    """Represents a message in the conversation."""
    role: ChatRole  # Role of the sender (user, assistant, etc.)
    content: list[TextContent]  # List of text content within the message


class UserDetails(BaseModel):
    """Represents user details extracted from token."""
    id: str
    email: str
    username: str


class ChatInput(BaseModel):
    """Represents the input for a chat request."""
    prompt: str = Field(..., description="The user's input message")
    chat_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for the chat session"
    )


class ChatSummary(BaseModel):
    """Represents a summary of a chat session."""
    id: str
    user_id: str
    title: str
    created_at: str
    updated_at: str


class Chat(ChatSummary):
    """Represents a full chat session, including messages."""
    messages: List[Message]
    user_email: str
    user_username: str


class ChatResponse(BaseModel):
    """Represents the response to a chat request."""
    message: Message
    chat: ChatSummary


def invoke_bedrock_agent(prompt: str, session_id: str) -> str:
    """Invoke Bedrock Agent with the given prompt"""
    try:
        bedrock_client = boto3.client("bedrock-agent-runtime", region_name="us-east-1")
        response = bedrock_client.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=prompt,
        )

        event_stream = response['completion']
        final_answer = ""
        for event in event_stream:
            if 'chunk' in event:
                chunk = event['chunk']['bytes']
                final_answer += chunk.decode('utf8')
            elif 'trace' in event:
                logger.info(json.dumps(event['trace'], indent=2))

        return final_answer.strip()

    except Exception as e:
        logger.error(f"Bedrock Agent invocation error: {e}")
        raise Exception(f"Error processing request: {str(e)}")


def save_chat_to_dynamodb(chat: Chat) -> None:
    """Saves the chat object to DynamoDB"""
    try:
        table.put_item(Item=json.loads(chat.model_dump_json()))
    except ClientError as e:
        logger.error(f"Error saving chat to DynamoDB: {e}")
        raise


def get_chat_from_dynamodb(chat_id: str) -> Optional[Chat]:
    """Fetches a chat session from DynamoDB"""
    try:
        response = table.get_item(Key={'id': chat_id})
        if 'Item' in response:
            return Chat(**response['Item'])
        return None
    except ClientError as e:
        logger.error(f"Error retrieving chat: {e}")
        return None


def get_chats_from_dynamodb(user_id: str) -> List[ChatSummary]:
    """Fetches all chat session summaries for a user"""
    try:
        response = table.scan(
            FilterExpression="user_id = :user_id",
            ExpressionAttributeValues={":user_id": user_id}
        )
        # Convert each Chat item to a ChatSummary
        return [ChatSummary(
            id=item['id'],
            user_id=item['user_id'],
            title=item['title'],
            created_at=item['created_at'],
            updated_at=item['updated_at']
        ) for item in response.get('Items', [])]
    except ClientError as e:
        logger.error(f"Error retrieving chats: {e}")
        return []


def lambda_handler(event, context):
    """Lambda handler with Pydantic model validation"""
    logger.info(f"Received event: {json.dumps(event)}")

    http_method = event.get('httpMethod', '')
    path = event.get('path', '')

    # Validate ID token
    headers = event.get('headers', {}) or {}
    id_token = headers.get('id_token', headers.get('Id-Token', ''))

    try:
        if not id_token:
            return create_response(400, {'error': 'id_token header is missing'})

        try:
            decoded_token = decode_id_token(id_token)
            user_details = UserDetails(**extract_user_details(decoded_token))
        except ValueError as ve:
            return create_response(400, {'error': str(ve)})

        # Route handling
        if http_method == 'GET' and path == '/search':
            chats = get_chats_from_dynamodb(user_details.id)
            return create_response(200, [chat.model_dump() for chat in chats])

        elif http_method == 'GET' and path.startswith('/chat/'):
            chat_id = path.split('/')[-1]
            chat = get_chat_from_dynamodb(chat_id)
            if not chat:
                return create_response(404, {'error': 'Chat not found'})
            return create_response(200, chat.model_dump())

        elif http_method == 'POST' and path == '/chat':
            try:
                # Validate input using Pydantic
                body = json.loads(event.get('body', '{}'))
                chat_input = ChatInput(**body)

                session_id = str(uuid.uuid4())

                if not chat_input.chat_id:
                    chat_id = str(uuid.uuid4())
                    title = generate_title(chat_input.prompt)

                    chat = Chat(
                        id=chat_id,
                        user_id=user_details.id,
                        user_email=user_details.email,
                        user_username=user_details.username,
                        title=title,
                        messages=[],
                        created_at=datetime.datetime.now().isoformat(),
                        updated_at=datetime.datetime.now().isoformat()
                    )
                else:
                    chat = get_chat_from_dynamodb(chat_input.chat_id)
                    if not chat:
                        return create_response(404, {'error': 'Chat not found'})

                # Add user message
                user_message = Message(
                    role=ChatRole.user,
                    content=chat_input.prompt
                )
                chat.messages.append(user_message)

                # Get Bedrock response
                bedrock_response = invoke_bedrock_agent(chat_input.prompt, session_id)

                # Add assistant message
                assistant_message = Message(
                    role=ChatRole.assistant,
                    content=bedrock_response
                )
                chat.messages.append(assistant_message)

                # Update chat
                chat.updated_at = datetime.datetime.now().isoformat()
                save_chat_to_dynamodb(chat)

                # Create response
                response = ChatResponse(
                    message=assistant_message,
                    chat=ChatSummary(
                        id=chat.id,
                        user_id=chat.user_id,
                        title=chat.title,
                        created_at=chat.created_at,
                        updated_at=chat.updated_at
                    )
                )

                return create_response(200, response.model_dump())

            except Exception as e:
                logger.error(f"Chat processing error: {e}")
                return create_response(500, {'error': str(e)})

        elif http_method == 'OPTIONS':
            return create_response(200, {})

        else:
            return create_response(404, {'error': 'Not Found'})

    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return create_response(500, {'error': 'Internal Server Error'})